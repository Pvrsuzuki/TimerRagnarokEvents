@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo Instalando PyInstaller...
python -m pip install --upgrade pyinstaller
if errorlevel 1 (
    echo.
    echo Nao foi possivel instalar. Verifique se o Python esta instalado e no PATH.
    pause
    exit /b 1
)

echo.
echo Gerando o executavel...
python -m PyInstaller --onefile --noconsole --name TimerEventos timer_alarme.py
if errorlevel 1 (
    echo.
    echo Falha ao gerar o executavel.
    pause
    exit /b 1
)

echo.
echo Pronto! O arquivo esta em: %~dp0dist\TimerEventos.exe
echo Se quiser usar sprites proprios, crie a pasta "sprites" ao lado do .exe.
pause
