"""
Timer de eventos (Ragnarok) - janela flutuante sempre na frente.

- Arraste com o botão esquerdo para mover.
- Clique direito: menu (ver horários, silenciar, fechar).
- Duplo clique: silencia o alarme.
- MODO FANTASMA (Ctrl+Alt+T): a janela fica na frente de tudo, mas os cliques
  atravessam (não dá para clicar nela). Ctrl+Alt+T de novo volta ao modo edição.
  Atalhos globais: Ctrl+Alt+T = alternar | Ctrl+Alt+S = silenciar | Ctrl+Alt+Q = fechar.
- Alarme (borda amarela piscando + bipe) por 3 segundos quando faltarem 5 minutos.
- O "✕" no canto superior direito fecha o programa (some no modo fantasma).

Sprites próprios (opcional): coloque PNGs na pasta "sprites" ao lado deste
script, com os nomes: melancia.png, poring.png, tarot.png, tigrinho.png,
zumbi.png. Se o arquivo existir, ele é usado no lugar do desenho padrão.
"""
import ctypes
import json
import math
import os
import sys
import threading
import time
import tkinter as tk
from datetime import datetime, timedelta

try:
    import winsound
except ImportError:
    winsound = None

# No .exe (PyInstaller --onefile) __file__ aponta para uma pasta temporária,
# então usamos a pasta onde o próprio .exe está.
if getattr(sys, "frozen", False):
    PASTA = os.path.dirname(os.path.abspath(sys.executable))
else:
    PASTA = os.path.dirname(os.path.abspath(__file__))
WIN = sys.platform == "win32"
CONFIG = os.path.join(PASTA, "config.json")
AVISO = timedelta(minutes=5)
DURACAO_ALARME = 3   # segundos que o alarme (som + borda piscando) dura

# chave: (nome, cor do nome, horários diários)
EVENTOS = {
    "melancia": ("Caça às Melancias", "#4cd964", ["10:00", "14:00", "18:00", "22:00"]),
    "poring":   ("Poring Premiado",   "#ff8ad8", ["13:00", "21:00"]),
    "tarot":    ("Tarot",             "#ff4d4d", ["11:00", "17:00"]),
    "tigrinho": ("Tigrinho da Sorte", "#ff4d4d", ["00:05", "12:00", "16:00", "20:00"]),
    "zumbi":    ("Arena Zumbi",       "#b5651d", ["19:00", "23:00"]),
}

BG, FG, FG_DIM, BORDA = "#1e1e2e", "#ffffff", "#9aa0b4", "#ffd400"
TAM = 44            # tamanho do ícone em pixels (os desenhos são feitos em 64)
ESC = TAM / 64


# ---------- ícones desenhados (usados se não houver PNG) ----------
def d_melancia(c, t):
    b = abs(math.sin(t * 5)) * 14            # pulo
    cy = 30 - b
    c.create_oval(20 + b / 2, 56, 44 - b / 2, 61, fill="#14141f", outline="")
    c.create_arc(8, cy - 24, 56, cy + 24, start=180, extent=180, style="chord",
                 fill="#e8383d", outline="#2e9e3e", width=5)
    for x, y in ((24, 8), (32, 14), (40, 8), (28, 18), (36, 20)):
        c.create_oval(x - 2, cy + y - 3, x + 2, cy + y + 3, fill="#111", outline="")


def d_poring(c, t):
    b = abs(math.sin(t * 4)) * 10
    c.create_oval(20 + b / 3, 58, 44 - b / 3, 62, fill="#14141f", outline="")
    c.create_oval(8, 26 - b, 56, 58 - b / 3, fill="#ff9fcf", outline="#e0629f", width=2)
    for x in (22, 38):
        c.create_oval(x - 4, 38 - b / 2, x + 4, 46 - b / 2, fill="#222", outline="")
        c.create_oval(x - 2, 39 - b / 2, x, 41 - b / 2, fill="#fff", outline="")
    c.create_arc(27, 44 - b / 2, 37, 52 - b / 2, start=200, extent=140,
                 style="arc", outline="#a03060", width=2)


def d_tarot(c, t):
    b = math.sin(t * 3) * 4
    c.create_rectangle(16, 6 + b, 48, 58 + b, fill="#f5f0e6", outline="#b22222", width=3)
    c.create_polygon(32, 16 + b, 42, 32 + b, 32, 48 + b, 22, 32 + b,
                     fill="#6a3fb5", outline="#3d2272")
    c.create_oval(28, 28 + b, 36, 36 + b, fill="#ffd400", outline="")


def d_tigrinho(c, t):
    b = math.sin(t * 3) * 3
    c.create_polygon(8, 24 + b, 12, 4 + b, 28, 16 + b, fill="#f39c12", outline="#111")
    c.create_polygon(56, 24 + b, 52, 4 + b, 36, 16 + b, fill="#f39c12", outline="#111")
    c.create_oval(8, 12 + b, 56, 58 + b, fill="#f39c12", outline="#111", width=2)
    for x1, y1, x2, y2 in ((32, 14, 32, 24), (23, 15, 26, 24), (41, 15, 38, 24),
                           (10, 34, 18, 36), (54, 34, 46, 36)):
        c.create_line(x1, y1 + b, x2, y2 + b, fill="#111", width=3)
    c.create_oval(18, 38 + b, 46, 56 + b, fill="#fff6e0", outline="")
    for x in (22, 42):
        c.create_oval(x - 5, 26 + b, x + 5, 34 + b, fill="#fff", outline="#111")
        c.create_oval(x - 2, 28 + b, x + 2, 33 + b, fill="#111", outline="")
    c.create_polygon(28, 41 + b, 36, 41 + b, 32, 46 + b, fill="#e0627a", outline="")
    c.create_line(32, 46 + b, 32, 50 + b, 27, 53 + b, fill="#111", width=2)
    c.create_line(32, 50 + b, 37, 53 + b, fill="#111", width=2)


def d_zumbi(c, t):
    s = math.sin(t * 3) * 4
    c.create_rectangle(22, 38, 30, 58, fill="#3b3b5c", outline="")
    c.create_rectangle(34, 38, 42, 58, fill="#3b3b5c", outline="")
    c.create_rectangle(18, 28, 46, 46, fill="#556b2f", outline="#2f3d19", width=2)
    c.create_rectangle(4, 30 + s, 18, 36 + s, fill="#8fbc8f", outline="#4f6f4f")
    c.create_rectangle(46, 30 - s, 60, 36 - s, fill="#8fbc8f", outline="#4f6f4f")
    c.create_rectangle(20, 4, 44, 28, fill="#8fbc8f", outline="#4f6f4f", width=2)
    for x in (25, 35):
        c.create_oval(x, 11, x + 5, 17, fill="#d62828", outline="")
    c.create_line(26, 23, 38, 23, fill="#222", width=2)
    for x in (29, 32, 35):
        c.create_line(x, 21, x, 25, fill="#222")


DESENHOS = {"melancia": d_melancia, "poring": d_poring, "tarot": d_tarot,
            "tigrinho": d_tigrinho, "zumbi": d_zumbi}


class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.attributes("-alpha", 0.94)
        self.root.configure(bg=BG, highlightthickness=2,
                            highlightbackground=BG, highlightcolor=BG)
        cfg = self.carregar_cfg()
        self.root.geometry(f"+{cfg.get('x', 40)}+{cfg.get('y', 40)}")
        self.fantasma = False
        self.teclas = {}

        self.alvo = None         # (datetime, chave)
        self.avisados = set()
        self.alarme = None       # alvo em alarme
        self.alarme_ate = datetime.min
        self.fim = None          # (chave, até quando mostra "AGORA")
        self.n = 0
        self.icone = None
        self.sprites = self.carregar_sprites()

        self.canvas = tk.Canvas(self.root, width=TAM, height=TAM, bg=BG,
                                highlightthickness=0)
        self.canvas.pack(side="left", padx=(5, 0), pady=3)
        col = tk.Frame(self.root, bg=BG)
        col.pack(side="left")
        self.lbl_nome = tk.Label(col, fg=FG, bg=BG, font=("Segoe UI", 9, "bold"),
                                 padx=6, anchor="w")
        self.lbl_tempo = tk.Label(col, fg=FG, bg=BG, font=("Consolas", 18, "bold"),
                                  padx=6, anchor="w")
        self.lbl_hora = tk.Label(col, fg=FG_DIM, bg=BG, font=("Segoe UI", 7),
                                 padx=6, anchor="w")
        for w in (self.lbl_nome, self.lbl_tempo, self.lbl_hora):
            w.pack(anchor="w")
        for w in (self.root, self.canvas, col, self.lbl_nome, self.lbl_tempo, self.lbl_hora):
            w.bind("<ButtonPress-1>", self.inicio_arrasto)
            w.bind("<B1-Motion>", self.arrastar)
            w.bind("<Double-Button-1>", lambda e: self.silenciar())
            w.bind("<Button-3>", self.menu)

        self.lbl_nome.pack_configure(padx=(0, 14))      # espaço para o ✕
        self.btn_x = tk.Label(self.root, text="✕", fg=FG_DIM, bg=BG,
                              font=("Segoe UI", 8, "bold"), cursor="hand2")
        self.btn_x.place(relx=1.0, x=-3, y=0, anchor="ne")
        self.btn_x.bind("<Button-1>", lambda e: self.root.destroy())
        self.btn_x.bind("<Enter>", lambda e: self.btn_x.config(fg="#ff4d4d"))
        self.btn_x.bind("<Leave>", lambda e: self.btn_x.config(fg=FG_DIM))

        self.tick()
        self.animar()
        self.root.after(300, lambda: self.definir_fantasma(cfg.get("fantasma", False), salvar=False))
        self.teclado()
        self.root.mainloop()

    # ---------- sprites ----------
    def carregar_sprites(self):
        sprites = {}
        pasta = os.path.join(PASTA, "sprites")
        self.diag = [f"Pasta procurada:\n{pasta}"]
        if os.path.isdir(pasta):
            self.diag.append("Arquivos encontrados nela: " +
                             (", ".join(os.listdir(pasta)) or "(vazia)"))
        else:
            self.diag.append("A pasta NÃO existe.")
        self.diag.append("")
        for chave in EVENTOS:
            caminho = os.path.join(pasta, chave + ".png")
            if not os.path.exists(caminho):
                self.diag.append(f"{chave}.png: não encontrado")
                continue
            try:
                img = tk.PhotoImage(file=caminho)
                f = max(1, math.ceil(max(img.width(), img.height()) / TAM))
                sprites[chave] = img.subsample(f) if f > 1 else img
                self.diag.append(f"{chave}.png: OK ({img.width()}x{img.height()})")
            except tk.TclError as err:
                self.diag.append(f"{chave}.png: erro ao abrir ({err})")
        return sprites

    def animar(self):
        t = time.time()
        c = self.canvas
        c.delete("all")
        if self.icone in self.sprites:
            quique = abs(math.sin(t * 5)) * 12 if self.icone == "melancia" else math.sin(t * 3) * 3
            c.create_image(32, 62 - quique, image=self.sprites[self.icone], anchor="s")
        elif self.icone in DESENHOS:
            DESENHOS[self.icone](c, t)
        c.scale("all", 0, 0, ESC, ESC)
        self.root.after(50, self.animar)

    # ---------- agenda ----------
    def proximo(self, agora):
        melhor = None
        for chave, (_, _, horas) in EVENTOS.items():
            for h in horas:
                hh, mm = map(int, h.split(":"))
                dt = agora.replace(hour=hh, minute=mm, second=0, microsecond=0)
                if dt <= agora:
                    dt += timedelta(days=1)
                if melhor is None or dt < melhor[0]:
                    melhor = (dt, chave)
        return melhor

    # ---------- som ----------
    def beep(self, tons=(880, 1175, 880, 1175)):
        if winsound:
            def run():
                for t in tons:
                    winsound.Beep(t, 150)
            threading.Thread(target=run, daemon=True).start()
        else:
            self.root.bell()

    # ---------- loop principal ----------
    def tick(self):
        agora = datetime.now()
        self.n += 1

        if self.alvo and agora >= self.alvo[0]:
            self.fim = (self.alvo[1], agora + timedelta(seconds=DURACAO_ALARME))
            self.alarme = None
            self.alvo = None
            self.beep((1000, 1000, 1000, 1500, 1500, 1500))
        if self.alvo is None:
            self.alvo = self.proximo(agora)

        borda = BG
        if self.fim and agora < self.fim[1]:
            nome, cor, _ = EVENTOS[self.fim[0]]
            self.icone = self.fim[0]
            self.lbl_nome.config(text=nome, fg=cor)
            self.lbl_tempo.config(text="AGORA!")
            self.lbl_hora.config(text=agora.strftime("%H:%M:%S") + self.aviso_modo())
            borda = BORDA if (self.n // 2) % 2 else BG
        else:
            dt, chave = self.alvo
            nome, cor, _ = EVENTOS[chave]
            falta = dt - agora
            if falta <= AVISO and self.alvo not in self.avisados:
                self.avisados.add(self.alvo)
                self.alarme = self.alvo
                self.alarme_ate = agora + timedelta(seconds=DURACAO_ALARME)
            s = int(falta.total_seconds())
            h, r = divmod(s, 3600)
            m, s = divmod(r, 60)
            self.icone = chave
            self.lbl_nome.config(text=nome, fg=cor)
            self.lbl_tempo.config(text=f"{h:02d}:{m:02d}:{s:02d}")
            self.lbl_hora.config(text=f"às {dt:%H:%M}  ·  agora {agora:%H:%M:%S}" + self.aviso_modo())
            if self.alarme == self.alvo and agora < self.alarme_ate:
                borda = BORDA if (self.n // 2) % 2 else BG
                if self.n % 4 == 0:
                    self.beep()

        self.root.config(highlightbackground=borda, highlightcolor=borda)

        if self.n % 4 == 0:                  # reforça "sempre na frente"
            self.root.attributes("-topmost", True)
            self.root.lift()
        self.root.after(250, self.tick)

    # ---------- modo fantasma (cliques atravessam a janela) ----------
    def carregar_cfg(self):
        try:
            with open(CONFIG, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def salvar_cfg(self):
        try:
            with open(CONFIG, "w", encoding="utf-8") as f:
                json.dump({"x": self.root.winfo_x(), "y": self.root.winfo_y(),
                           "fantasma": self.fantasma}, f)
        except OSError:
            pass

    def aviso_modo(self):
        return "" if self.fantasma else "  ·  EDIÇÃO"

    def alternar(self):
        self.definir_fantasma(not self.fantasma)

    def definir_fantasma(self, ligado, salvar=True):
        self.fantasma = ligado
        if ligado:
            self.btn_x.place_forget()
        else:
            self.btn_x.place(relx=1.0, x=-3, y=0, anchor="ne")
        if salvar:
            self.salvar_cfg()
        if not WIN:
            return
        u = ctypes.windll.user32
        h = u.GetAncestor(self.root.winfo_id(), 2)        # janela de nível superior
        estilo = u.GetWindowLongW(h, -20)                 # GWL_EXSTYLE
        base = 0x80000 | 0x80                             # LAYERED | TOOLWINDOW
        fantasma = 0x20 | 0x08000000                      # TRANSPARENT | NOACTIVATE
        estilo = (estilo | base | fantasma) if ligado else ((estilo | base) & ~fantasma)
        u.SetWindowLongW(h, -20, estilo)

    def teclado(self):
        """Atalhos globais (funcionam mesmo com outro programa em foco)."""
        if WIN:
            gk = ctypes.windll.user32.GetAsyncKeyState
            if gk(0x11) & 0x8000 and gk(0x12) & 0x8000:     # Ctrl + Alt
                for vk, acao in ((0x54, self.alternar), (0x53, self.silenciar),
                                 (0x51, self.root.destroy)):
                    atual = bool(gk(vk) & 0x8000)
                    if atual and not self.teclas.get(vk):
                        acao()
                        if vk == 0x51:
                            return
                    self.teclas[vk] = atual
            else:
                self.teclas.clear()
        self.root.after(50, self.teclado)

    # ---------- interação ----------
    def inicio_arrasto(self, e):
        self._dx = e.x_root - self.root.winfo_x()
        self._dy = e.y_root - self.root.winfo_y()

    def arrastar(self, e):
        self.root.geometry(f"+{e.x_root - self._dx}+{e.y_root - self._dy}")

    def silenciar(self):
        self.alarme = None

    def menu(self, e):
        m = tk.Menu(self.root, tearoff=0)
        m.add_command(label="Ver horários", command=self.ver_horarios)
        m.add_command(label="Travar (modo fantasma)  Ctrl+Alt+T", command=self.alternar)
        m.add_command(label="Diagnóstico dos sprites", command=self.ver_diag)
        m.add_command(label="Silenciar alarme", command=self.silenciar)
        m.add_separator()
        m.add_command(label="Fechar", command=self.root.destroy)
        m.tk_popup(e.x_root, e.y_root)

    def ver_diag(self):
        w = tk.Toplevel(self.root)
        w.title("Diagnóstico dos sprites")
        w.attributes("-topmost", True)
        tk.Label(w, text="\n".join(self.diag), justify="left", anchor="w",
                 wraplength=480, padx=12, pady=12).pack()

    def ver_horarios(self):
        w = tk.Toplevel(self.root)
        w.title("Horários")
        w.attributes("-topmost", True)
        w.configure(bg=BG)
        for nome, cor, horas in EVENTOS.values():
            tk.Label(w, text=nome, fg=cor, bg=BG, font=("Segoe UI", 10, "bold"),
                     anchor="w").pack(fill="x", padx=14, pady=(8, 0))
            tk.Label(w, text="  ".join(horas), fg=FG, bg=BG,
                     anchor="w").pack(fill="x", padx=14)
        tk.Label(w, text="", bg=BG).pack()


if __name__ == "__main__":
    App()
